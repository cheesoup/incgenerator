#ifndef _ENVELOPE_HEADER_DEFINITION
#define _ENVELOPE_HEADER_DEFINITION
#include "global.h"
#include "dsp.h"
#include "parameters.h"

namespace VOICE { namespace MODULATOR {
using namespace PARAMETER;

const float MINLVL = 0.0001f;
const float MINTIME = 0.001f;
	
typedef enum ENVSTAGE_ENUM {
	ENV_OFF = 0,
	ENV_ATTACK,
	ENV_DECAY,
	ENV_SUSTAIN,
	ENV_RELEASE,
	ENV_KILL
} ENVSTAGE_ENUM;

class Modulator {
	protected:
	float _current;
	public:
	Modulator() {}
	virtual ~Modulator() {}
	virtual const float * getPointer() const { return &_current; }
};

class Envelope : public Modulator {
	typedef enum ADSR_ENUM {
		ADSR_ATTACK = 0,
		ADSR_DECAY,
		ADSR_SUSTAIN,
		ADSR_RELEASE
	} ADSR_ENUM;
	
	ENVSTAGE_ENUM _stage = ENV_OFF;
	uint _timer = 0;
	float _adsr[ADSR_RELEASE + 1] = { 0 };
	float _coef = 1.0f, _vel = 0.0f;
	
	inline float sustain() const;
	inline uint timer(ADSR_ENUM stage, float max) const;
	inline void setADSR(float atk, float dec, float sus, float rel);
	void goStage(ENVSTAGE_ENUM next);
		
	public:
	Envelope(float atk = 0.0f, float dec = 0.0f, float sus = 0.0f, float rel = 0.0f);
	float process(void);
	void trigger(float atk = 0.0f, float dec = 0.0f, float sus = 0.0f, float rel = 0.0f, float vel = 0.0f);
	void release(bool kill = false);
	ENVSTAGE_ENUM getStage() const { return _stage; }
};

typedef enum CLICKSTAGE {
	CLICK_OFF		= 0,
	CLICK_ATTACK	= 1,
	CLICK_RELEASE	= 2,
	CLICK_KILL		= 3
} CLICKSTAGE_ENUM;

class Click : public Modulator {
	CLICKSTAGE_ENUM _stage = CLICK_OFF;
	uint	_timer = 0;
	uint	_response[2];
	float	_vel = 0.0f;
	float	_coef = 1.0f;
	
	void goStage(CLICKSTAGE_ENUM stage);
	
	public:
	Click(float atk = 0.1f, float rel = 0.333f) {
		_response[0] = (int)(atk * *SAMPLERATE);
		_response[1] = (int)(rel * *SAMPLERATE);
	}
	
	float process();
	void trigger(float atk = std::nanf(""), float rel = std::nanf(""), float vel = 0.0f);
	void kill();
	CLICKSTAGE_ENUM getStage() { return _stage; }
};

class LFO : public Modulator {
	float _phase = 0.0f;
	
	public:
	LFO() {}
	
	float process(float freq);
	float getCurrent() { return _current; }
};
}}

#endif