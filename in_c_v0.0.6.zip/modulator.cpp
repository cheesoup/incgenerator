#include "modulator.h"
using namespace VOICE::MODULATOR;

//~~~~~~~~~~//
// ENVELOPE //
//~~~~~~~~~~//

Envelope::Envelope(float atk, float dec, float sus, float rel) {
	_current = 0.0f;
	setADSR(atk, dec, sus, rel);
}

float Envelope::process(void) {
	if ((_stage != ENVSTAGE_ENUM::ENV_OFF) && (_stage != ENVSTAGE_ENUM::ENV_SUSTAIN)) {
		if (_timer <= 0){
			uint next = _stage + 1;
			next *= next <= ENV_KILL;
			goStage(static_cast<ENVSTAGE_ENUM>(next));
		}
		_current *= _coef;
		_timer--;
	}
	return _current;
}

void Envelope::trigger(float atk, float dec, float sus, float rel, float vel) {
	if (!vel) {
		_vel = 0.0f;
		release();
	}
	else {
		_vel = vel;
		setADSR(atk, dec, sus, rel);
		goStage(ENV_ATTACK);
	}
}

void Envelope::release(bool kill) {
	goStage(kill ? ENV_KILL : ENV_RELEASE);
}

void Envelope::goStage(ENVSTAGE_ENUM stage) {
	_stage = stage;
    switch (_stage) {
        default:
        	_stage = ENV_OFF;
        case ENV_OFF:
			_current = 0.0f;
        	_timer = 0;
			_coef = 1.0f;
            break;
        case ENV_ATTACK:
			_current = MINLVL;
        	_timer = timer(ADSR_ATTACK, 0.5f);
			_coef = DSP::EXPRAMP_COEF(_current, _vel, _timer);
            break;
        case ENV_DECAY:
        	_timer = timer(ADSR_DECAY, 2.0f);
			_current = _vel;
			_coef = DSP::EXPRAMP_COEF(_current, sustain(), _timer);
            break;
        case ENV_SUSTAIN:
        	_timer = 0;
			_current = sustain();
			_coef = 1.0f;
            break;
        case ENV_RELEASE:
        	_timer = timer(ADSR_RELEASE, 2.0f);
			_coef = DSP::EXPRAMP_COEF(_current, MINLVL, _timer);
            break;
        case ENV_KILL:
        	_timer = 0.005f * *SAMPLERATE;
        	_coef = DSP::EXPRAMP_COEF(_current, MINLVL, _timer);
        	break;
    }
}

inline void Envelope::setADSR(float atk, float dec, float sus, float rel) {
	_adsr[ADSR_ATTACK] = atk;
	_adsr[ADSR_DECAY] = dec;
	_adsr[ADSR_SUSTAIN] = sus;
	_adsr[ADSR_RELEASE] = rel;
}

// Actual sustain = sustain^2
inline float Envelope::sustain() const {
	return fmaxf(MINLVL, _adsr[ADSR_SUSTAIN] * _vel);
}
	
// Calculate sample length of an envelope stage
inline uint Envelope::timer(ADSR_ENUM stage, float max) const {
	return (uint)(fmaxf(MINTIME, _adsr[stage] * _adsr[stage] * max) * *SAMPLERATE);
}

//~~~~~~~//
// CLICK //
//~~~~~~~//

float Click::process() {
	if (_stage != CLICK_OFF) {
		if (_timer <= 0) {
			uint next = _stage + 1;
			next *= next <= CLICK_KILL;
			goStage(static_cast<CLICKSTAGE_ENUM>(next));
		}
		_current *= _coef;
		_timer--;
	}
	
	return _current;
}

void Click::trigger(float atk, float rel, float vel) {
	if (vel > 0.0f) {
		_vel = vel;
		_response[0] = std::isnan(atk) ? _response[0] : (int)(DSP::CLIP(atk * 0.25f) * *SAMPLERATE);
		_response[1] = std::isnan(rel) ? _response[1] : (int)(DSP::CLIP(rel) * *SAMPLERATE);
		goStage(CLICK_ATTACK);
	}
}

void Click::kill() {
	goStage(CLICK_KILL);
}

void Click::goStage(CLICKSTAGE_ENUM stage) {
	_stage = stage;
	switch(_stage) {
		default:
			_stage = CLICK_OFF;
		case CLICK_OFF:
			_current = 0.0f;
	    	_timer = 0;
			_coef = 1.0f;
			break;
		case CLICK_ATTACK:
			_current = MINTIME;
			_timer = _response[0];
			_coef = DSP::EXPRAMP_COEF(_current, _vel, _timer);
			break;
		case CLICK_RELEASE:
			_current = _vel;
			_timer = _response[1];
			_coef = DSP::EXPRAMP_COEF(_current, MINTIME, _timer);
			break;
		case CLICK_KILL:
			_timer = (int)(0.005f * *SAMPLERATE);
			_coef = DSP::EXPRAMP_COEF(_current, MINTIME, _timer);
			break;
	}
}

//~~~~~//
// LFO //
//~~~~~//

float LFO::process(float freq) {
	_current = DSP::SIN2(_phase);
	
	float delta = freq * 20.0f * *ONE_OVER_SAMPLERATE;
	_phase += delta;
	_phase -= (int)_phase;
	
	return _current;
}