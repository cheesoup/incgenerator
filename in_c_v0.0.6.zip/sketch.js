const windowScale = 0.95;
var hexR, hexS;
var hexMap = [];
var playerList = [];
var presets, controls, synth, wave, adsr;
var metronome;
var drawconsole;
var font;

function preload() {
	let url = "./js/defaults.json";
	loadJSON(url, function(settings) { 
		presets = settings.presets;
	});
	font = loadFont("./assets/SourceCodePro-Regular.otf");
}

function displayControl(control) {
	synth.style("display", "none");
	wave.style("display", "none");
	adsr.style("display", "none");
	if (control == "SYNTH")	synth.style("display", "block");
	else if (control == "WAVE")	wave.style("display", "block");
	else if (control == "ADSR")	adsr.style("display", "block");
}

function setup() {
	setAttributes('antialias', true);
	let cnv = createCanvas(windowWidth * windowScale, windowHeight * windowScale, WEBGL);
	cnv.parent('Sketch');
	frameRate(30);
	buildControls();
	buildHexMap();
	metronome = new Metronome();
	drawconsole = new DrawConsole();
}

function draw() {
	background(10, 10, 10, 100);
	color(255, 255, 255, 100);
	
	let c = 0;
	
	hexMap.forEach((g) => {
		hexMap[c].forEach((h) => {
			h.render();
		});
		c++;
	});
	
	playerList.forEach((p) => {
		p.draw();
	});
	
	drawconsole.draw();
	//metronome.draw();
}

function hexagon(x, y, r) {
	push();
	stroke(127, 127, 127, 100);
	beginShape();
	for (let a = 0; a < 2 * PI; a += (2 * PI) / 6) {
		let x2 = cos(a) * r;
		let y2 = sin(a) * r;
		vertex(x + x2, y + y2);
	}
	endShape(CLOSE);
	pop();
}

class Hexagon {
	constructor(x, y, r, name) {
		this.x = x;
		this.y = y;
		this.r = r;
		this.name = name;
	}
	render() {
		noFill();
		strokeWeight(1);
		stroke(255,255,255,255);
		hexagon(this.x, this.y, this.r);
	}
}

function buildHexMap() {
	hexR = 40;
	hexS = Math.sqrt((3 * Math.pow(hexR, 2)) / 4);
	startx = -9 * hexR - hexS;
	startY = -5 * hexS;
	// create hexagons
	let counter;
	let x = 0;
	let y = 0;
	
	for (let i = 0; i < 7; i++) {
		hexMap[i] = [];
		counter = 0;
		y = 0;
		for (let j = 0; j < 6; j++) {
			hexMap[i].push(new Hexagon(startx + x, startY + y, hexR, counter++));
			hexMap[i].push(new Hexagon(startx + x + 1.5 * hexR, startY + y + hexS, hexR, counter++));
			y += 2 * hexS;
		}
		x += 3 * hexR;
	}
}

class Beat {
	constructor() {
		this.size = 30;
		this.stroke = 10;
	}
	
	draw() {
		push();
		fill(0, 0, 0, 0);
		stroke(255, 255, 255, 100);
		strokeWeight(this.stroke);
		smooth();
		circle(0, 0, this.size);
		pop();
		if (this.stroke > 1) this.stroke--;
		if (this.size) this.size -= 2;
		return this.size !== 0;
	}
}

class Metronome {
	constructor() {
		this.beats = [];
	}
	
	newbeat() {
		var new_beat = new Beat();
		this.beats.push(new_beat);
	}
	
	draw() {
		let deletelist = [];
		for (let i = 0; i < this.beats.length; i++) {
			if (!this.beats[i].draw()) {
				deletelist.push(this.beats[i]);
			}
		}
		for (let i = 0; i < deletelist.length; i++) this.beats.splice(deletelist[i], 1);
	}
}

function windowResized() {
	resizeCanvas(windowWidth * windowScale, windowHeight * windowScale);
}

class Note {
	constructor(x, y, note, data, settings, id = "") {
		this.x = x;
		this.y = y;
		
		this.hue = (((data.note % 12) * 7) % 12 / 12);
		this.hue = Math.max(0, Math.min(1, this.hue));
		this.hue *= 127;
		this.white = data.note;
		
		let decay = settings.find(o => o.name === "DECAY");
		this.decay = decay.value + decay.value * data.lfo * (decay.mod_value * 2.0 - 1.0);
		this.decay = Math.max(0, Math.min(1, this.decay));
		this.decay = (1 - this.decay) * 3 + 1;
		
		let lvl = settings.find(o => o.name === "LEVEL");
		this.size = data.vel * lvl.value * 320;
		this.id = id;
		this.max = this.size;
		
		/*
		let shape = settings.find(o => o.name === "SHAPE");
		this.shape = shape.value + shape.mod_value * shape.value * data.lfo;
		
		let sub = settings.find(o => o.name === "SUB");
		this.sub = sub.value + sub.mod_value * sub.value * data.lfo;
		
		let pw = settings.find(o => o.name === "PW");
		this.pw = pw.value + pw.mod_value * pw.value * data.lfo;
		*/
	}
	
	draw() {
		push();
		colorMode(RGB, 127);
		fill(127, 127, 127, (this.size / this.max) * 127);
		textFont(font);
		textSize(8);
		text(this.id, this.x+ 10, this.y + 10);
		pop();
		
		push();
		colorMode(HSB, 127);
		noFill(0);
		stroke(this.hue, 127, this.white);
		strokeWeight(1);
		circle(this.x, this.y, this.size);
		pop();
		let out = this. size > 0;
		if (this.size > 0) this.size -= this.decay;
		this.decay = Math.max(0, this.decay);
		return out;
	}
}

class Player {
	constructor(index, id, settings) {
		this.index = index;
		this.id = id;
		this.settings = settings;
		this.notes = [];
		this.sequence = 0;
	}
	
	setSettings(data) {
		let selected = this.settings.find(o => o.name === data.command);
		switch(data.attribute) {
			case "user":
				selected.value = data.value;
				break;
			case "mod":
				selected.mod_value = data.value;
				break;
			default:
				break;
		}
	}
	
	newNote(data) {
		if (!document.hidden && data.vel) {
			let pan = this.settings.find(o => o.name === "PAN");
			if (!pan) return;
			let x = -(pan.value * 2.0 - 1.0);
			x += data.lfo * (pan.mod_value * 2.0 - 1.0);
			x = Math.round(x * 3.0 + 3.0);
			x = Math.min(hexMap.length - 1, Math.max(0, x));
			
			let y = data.note % 12;
			let hex = hexMap[x][y];
			let newNote = new Note(hex.x, hex.y, y, data, this.settings, this.id);
			this.notes.push(newNote);
		}
	}
	
	newSequence(data) {
		if (this.sequence !== data.sequence) {
			this.sequence = data.sequence;
			return true;
		}
		return false;
	}
	
	draw() {
		let dellist = [];
		
		push();
		beginShape();
		this.notes.forEach((note) => {
			let timer = note.draw();
			if (!timer) dellist.push(note);
			vertex(note.x, note.y);
		});
		endShape();
		dellist.forEach((note) => {
			this.notes.splice(note, 1);
		});
	}
}

class DrawConsole {
	constructor() {
		this.msgs = [];
	}
	newMsg(message) {
		if (!document.hidden) {
			let newMsg = new DrawConsoleMsg(message);
			this.msgs.push(newMsg);
		}
	}
	draw() {
		let del = [];
		for (let i = 0; i < this.msgs.length; i++) {
			if (!this.msgs[i].draw(15 - width * 0.5, (height * 0.5 - 15) - (20 * i))) del.push(this.msgs[i]);
		}
		del.forEach((selected) => {
			this.msgs.splice(selected, 1);
		});
	}
}

class DrawConsoleMsg {
	constructor(msg) {
		this.msg = msg;
		this.timer = 30;
	}
	
	draw(x, y) {
		push();
		colorMode(RGB, 127);
		fill(127, 127, 127);
		textFont(font);
		textSize(10);
		text(this.msg, x, y);
		pop();
		if (this.timer) this.timer--;
		return this.timer > 0;
	}
}