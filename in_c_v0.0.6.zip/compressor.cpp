#include "compressor.h"

using namespace MASTER;

Compressor::Compressor(uint rmsSize, uint lookahead):
	_rmsSize(rmsSize), 
	_bufferSize(rmsSize + lookahead), 
	_oneoverSize(1.0f / (float)_rmsSize), 
	_writeptr(0)
{
	_buffer[0] = new float[_bufferSize]{ 0.0f };
	_buffer[1] = new float[_bufferSize]{ 0.0f };
	
	setParameter(COMP_ATK, 10.0f);
	setParameter(COMP_REL, 20.0f);
	setParameter(COMP_THRESH, -6.0f);
	setParameter(COMP_SLOPE, 16.0f);
	setParameter(COMP_PREGAIN, 9.0f);
	setParameter(COMP_POSTGAIN, 0.0f);
}

const Audio & Compressor::process(const Audio &input) {
	const float rms = calculateRMS(input.get(CHANNEL_LEFT), input.get(CHANNEL_RIGHT)); // calculate RMS from total
	const float env = applyEnvelope(rms); // Apply attack/release envelope
	
	// Compute gain correction and apply
	float gain = _parameters[COMP_SLOPE] * (_parameters[COMP_THRESH] - DSP::LINTODB(env));
	gain = DSP::DBTOLIN(gain) * DSP::DBTOLIN(_parameters[COMP_POSTGAIN]);

	// Apply gain correction + sigmoid
	_current[CHANNEL_LEFT] = _buffer[CHANNEL_LEFT][_writeptr] * gain * _parameters[COMP_POSTGAIN];
	_current[CHANNEL_RIGHT] = _buffer[CHANNEL_RIGHT][_writeptr] * gain * _parameters[COMP_POSTGAIN];
	
	// Write input to buffer and increment write pointer
	_buffer[CHANNEL_LEFT][_writeptr] = input.get(CHANNEL_LEFT);
	_buffer[CHANNEL_RIGHT][_writeptr] = input.get(CHANNEL_RIGHT);
	_writeptr++;
	_writeptr *= _writeptr < _bufferSize;
	
	return _current;
}

inline float Compressor::calculateRMS(float left, float right) {
	static float squaredsum = 0.0f; // Running sum for calculating RMS
	left *= _parameters[COMP_PREGAIN];
	right *= _parameters[COMP_PREGAIN];
	
	// Calculate the index of the oldest sample within the RMS window
	int rmsLastSampleIdx = _writeptr - _rmsSize;
	rmsLastSampleIdx += (rmsLastSampleIdx < 0) * _bufferSize;
	
	// Add new value and remove old value from running total.
	const float newSample = sqravg(left * _parameters[COMP_PREGAIN], right * _parameters[COMP_PREGAIN]);
	const float oldSample = sqravg(_buffer[0][rmsLastSampleIdx], _buffer[1][rmsLastSampleIdx]);
	squaredsum += newSample;
	squaredsum -= oldSample;
	
	return sqrtf_neon(squaredsum * _oneoverSize);
}

inline float Compressor::applyEnvelope(float x) {
	static float env = 0.0f;
	const float *theta = &_parameters[x > env];
	return (1.0 - *theta) * x + *theta * env;
}

void Compressor::setParameter(COMP_ENUM param, float value) {
	switch(param) {
		case COMP_ATK:
		case COMP_REL:
			value = value <= 0.0f ? 0.0f : expf_neon(-1.0f * *SAMPLERATE * value);
			break;
		case COMP_PREGAIN:
		case COMP_POSTGAIN:
		case COMP_THRESH:
			value = powf_neon(10.0f, value * 0.05f);
			break;
		case COMP_SLOPE:
			value = 1 - (1.0f / value);
			break;
	}
	_parameters[param] = value;
}