#ifndef _DELAY_HEADER_DEFINITION
#define _DELAY_HEADER_DEFINITION

#include "global.h"
#include "dsp.h"
#include "audio.h"

namespace DSP {
class Delay {
	protected:
	const uint _size;
	uint _writeptr;
	float * _buffer;
	
	public:
	Delay(float size);
	virtual ~Delay() { delete[] _buffer; }
	virtual float process(float input);
	virtual void feed(float input);
	virtual void advance();
	virtual float tap(float length = 0.0f);
	float vtap(float length = 0.0f);
	
	virtual float getCurrent() { return _buffer[_writeptr]; }
	uint getSize() { return _size; }
	uint getPosition() { return _writeptr; }
};

class StereoDelay {
	Audio _current;
	Delay *_del[2];
	
	public:
	StereoDelay(float size);
	~StereoDelay() { for (Delay *selected : _del) delete[] selected; }
	
	void process(float delay, float fb, bool pingpong);
};
}

#endif