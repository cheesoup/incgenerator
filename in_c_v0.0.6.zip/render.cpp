// TODO:

/*
- Port synth code to new project
	- Simplify to allow more voices
	- Make code less shitty
- OSC + Parameter Manager + Sequence Controls
- Put together full In C MidiFile
- NodeJS & OSC + Website Design
- Hardware Controls
*/

#include <libraries/OscSender/OscSender.h>
#include <libraries/OscReceiver/OscReceiver.h>
#include <libraries/Scope/Scope.h>

#include <JSON.h>
#include "global.h"
#include "audio.h"
#include "player.h"
#include "dsp.h"
#include "compressor.h"

// Out = Remote
const float gInertia = 0.2f;
const uint gInPort = 7562;
const uint gOutPort = 7563;
const char* gOutIP = "127.0.0.1";
JSONValue json;

const uchar ioPlay = 2;
const uchar ioBeat = 1;
const uchar ioLED = 0;

// Global Links
const float *INERTIA;
const float *SAMPLERATE;
const float *ONE_OVER_SAMPLERATE;

// OSC stuff
OscReceiver oscReceiver;
OscSender oscSender;
Scope scope;

// Variables & Class Instances

PLAYER::PlayerManager *gPlayers;
MASTER::Compressor *gCompressor;
bool gServerReady;

void startServer(void *arg) {
	const std::string args_str[2] = { "node", "web/bridge" };
	const auto error = []() {
		rt_printf("Error: NodeJS server failed to start. Please start it manually.\n");
	};
	
	char *args[3] = { (char*)args_str[0].c_str(), (char*)args_str[1].c_str(), NULL };
	int pid = fork();
	
	if (pid == 0) {	if (execvp(args[0], args) == -1) error(); }
	else if(pid == -1) { error(); }
}

void sendOSC(const std::string &command = "/osctest", const std::string &id = "", uint size = 0,  ...) {
	oscpkt::Message msg;
	va_list args;
	
	msg.init(command);
	if (id.length()) msg.pushStr(id);
	va_start(args, size);
	while (size-- > 0) msg.pushFloat((float)va_arg(args, double));
	va_end(args);
	oscSender.send(msg);
}

void receiveOSC(oscpkt::Message *msg, void *arg) {
	oscpkt::Message out;
	std::string id;
	std::string command;
	std::string attribute;
	float val = 0.0f;
	
	if(msg->match("/start")) {
		gPlayers->play();
		return;
	}
	if(msg->match("/register")) {
		bool connected;
		msg->match("/register").popStr(id).popBool(connected);
		if (!(gPlayers->isPlaying())) { 
			if (connected) {
				std::string playerlist;
				gPlayers->dumpPlayers(playerlist);
				gPlayers->create(id);
				out.init("/confirm").pushStr(id).pushBool(true);
				oscSender.send(out);
			} else gPlayers->destroy(id);
		} else {
			gPlayers->destroy(id);
			out.init("/confirm").pushStr(id).pushBool(false);
			oscSender.send(out);
		}
		return;
	}
	if(msg->match("/control").popStr(command).popStr(id).isOkNoMoreArgs()) {
		gPlayers->control(command, id);
		return;
	}
	if (msg->match("/control").popStr(command).popStr(id).popFloat(val).isOkNoMoreArgs()) { 
		gPlayers->control(command, id, val);
		return;
	}
	if (msg->match("/control").popStr(command).popStr(id).popStr(attribute).popFloat(val).isOkNoMoreArgs()) { 
		gPlayers->control(command, id, val, attribute);
		return;
	}
}

bool setup(BelaContext *context, void *userData) {
	Bela_runAuxiliaryTask(startServer, 15, NULL);
	
	if (SCOPE_ON) scope.setup(2, context->audioSampleRate);
	oscReceiver.setup(gInPort, receiveOSC);
    oscSender.setup(gOutPort, gOutIP);
	
	pinMode(context, 0, ioBeat, INPUT);
	pinMode(context, 0, ioPlay, INPUT);
	pinMode(context, 0, ioLED, OUTPUT);
	
	// Assign the sample rate pointer and
	// the reciprocal to global pointers
	SAMPLERATE = &(context->audioSampleRate);
	static const float isr = 1.0f / *SAMPLERATE;
	ONE_OVER_SAMPLERATE = &isr;
	INERTIA = &gInertia;
	
	gPlayers = new PLAYER::PlayerManager(sendOSC);
	gCompressor = new MASTER::Compressor(64, 192);
	
	oscpkt::Message out;
	out.init("/ready").pushBool(true);
	oscSender.send(out);
	
	return true;
}

void render(BelaContext *context, void *userData) {
	for(unsigned int n = 0; n < context->audioFrames; n++) {
		static bool last_switch = HIGH;
		bool play = digitalRead(context, n, ioPlay);
		if (play == LOW && last_switch == HIGH) {
			gPlayers->play(true);
		}
		if (play == HIGH && last_switch == LOW) {
			gPlayers->play(false);
		}
		last_switch = play;
		
		bool led = gPlayers->isPlaying();
		bool beat = gPlayers->newBeat();
		digitalWriteOnce(context, n, ioLED, led);
		digitalWriteOnce(context, n, ioBeat, beat ? HIGH : LOW);
		
		float clicklvl = 1.0f - analogRead(context, n, 0);
		
		Audio out = gPlayers->process(clicklvl);
		out = gCompressor->process(out);
		
		float volume = 1.0f - 1.33333f * analogRead(context, n, 1);
		out *= volume;
		
		if (SCOPE_ON) scope.log(out[CHANNEL_LEFT], out[CHANNEL_RIGHT]);
		for(unsigned int channel = 0; channel < context->audioOutChannels; channel++) {
			audioWrite(context, n, channel, out[channel]);
		}
	}
}

void cleanup(BelaContext *context, void *userData) {
	delete gPlayers;
}