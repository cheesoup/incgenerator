#ifndef _VOICE_HEADER_DEFINITION
#define _VOICE_HEADER_DEFINITION

#include "global.h"
#include "audio.h"
#include "parameters.h"
#include "oscillator.h"
#include "delay.h"
#include "filter.h"
#include "modulator.h"

namespace VOICE {
using namespace PARAMETER;
using namespace MODULATOR;
using namespace OSCILLATOR;
using namespace DSP;

class Pulse {
	Audio _current;
	uchar _index;
	float _period = 0.0f;
	
	IIRSine *_osc;
	IIRSine *_mod;
	Click *_env;
	Click *_click;
	Delay *_pluck;
	OnePole *_damp;
	AllPass *_diff;
	
	const float SINQTRPI = 0.70710678118f;
	
	public:
	Pulse(uchar index);
	~Pulse() {
		delete _osc;
		delete _mod;
		delete _env;
		delete _click;
		delete _pluck;
		delete _damp;
		delete _diff;
	}
	const Audio & process(void);
	void trigger(uchar note);
	void kill(void);
	uchar getIndex(void) const { return _index; }
	bool isActive(void) const { return _env->getStage() != CLICKSTAGE_ENUM::CLICK_OFF; }
};

class Voice {
	Audio _current;
	uchar _index;
	ParameterFlt *_atk, *_dec, *_sus, *_rel;
	ParameterFlt *_lvl, *_pan, *_pw;
	ParameterFlt *_sub, *_shape, *_bright;
	
	// DSP
	BasicWaves *_osc;
	IIRSine *_subosc;
	Envelope *_env;
	Click *_click;
	Delay *_pluck;
	OnePole *_damp;
	AllPass *_diff;
	OnePole *_hpf;
	
	// Variables
	float _freq = 0.0f, _delta = 0.0f, _period = 0.0f, _vel = 0.0f;
	float morph(float input, float phase, float brightness);
	
	public:
	// Constructor
	Voice(const ParameterManager &paramManager, const LFO *lfo, uchar index);
	~Voice() {
		delete _osc;
		delete _subosc;
		delete _env;
		delete _click;
		delete _pluck;
		delete _damp;
		delete _diff;
		delete _atk;
		delete _dec;
		delete _sus;
		delete _rel;
		delete _lvl;
		delete _pan;
		delete _pw;
		delete _sub;
		delete _shape;
		delete _bright;
	}
	
	// Processes
	const Audio & process();
	void noteOn(uint note, uint vel);
	void noteOff(bool kill = false);
	const Audio & getCurrent() const { return _current; }
	float getLevel() const { return _lvl->getFloat() * _vel; }
	uchar getIndex() const { return _index; }
};
}

#endif