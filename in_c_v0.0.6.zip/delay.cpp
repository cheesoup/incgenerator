#include "delay.h"

using namespace DSP;

//~~~~~~~//
// Delay //
//~~~~~~~//
Delay::Delay(float size):
_size((int)(size * *SAMPLERATE)), _writeptr(0) {
	_buffer = new float[_size];
	*_buffer = { 0.0f };
}

float Delay::process(float input) {
	float out = _buffer[_writeptr];
	feed(input);
	advance();
	return out;
}

float Delay::tap(float length) {
	int readptr = _writeptr - (int)DSP::CLIP(length * *SAMPLERATE, (float)_size - 1.0f, 1.0f);
	readptr += _size * (readptr < 0);
	return _buffer[readptr];
}

float Delay::vtap(float length) {
	float fltback = (float)_writeptr - DSP::CLIP(length * *SAMPLERATE, (float)_size - 1.0f, 1.0f);
	fltback += _size * (fltback < 0.0f);
	const int intback = (int)fltback;
	
	union ptr {	int i;	float f; };
	ptr readPtr[4];
	readPtr[0].i = intback - 1;
	readPtr[1].i = intback;
	readPtr[2].i = intback + 1;
	readPtr[3].i = intback + 2;
	
	readPtr[0].i += _size * (readPtr[0].i < 0);
	readPtr[2].i *= readPtr[2].i < _size;
	readPtr[3].i *= readPtr[3].i < _size;
	
	readPtr[0].f = _buffer[readPtr[0].i];
	readPtr[1].f = _buffer[readPtr[1].i];
	readPtr[2].f = _buffer[readPtr[2].i];
	readPtr[3].f = _buffer[readPtr[3].i];
	
	const float x = fltback - intback;
	const float coef[4] {
		readPtr[0].f,
		0.5f * (readPtr[2].f - readPtr[0].f),
		readPtr[0].f - 2.5f * readPtr[1].f + 2.0f * readPtr[2].f - 0.5f * readPtr[3].f,
		0.5f * (readPtr[3].f - readPtr[0].f) + 1.5f * (readPtr[1].f - readPtr[2].f)
	};
	return ((coef[3] * x + coef[2]) * x + coef[1]) * x + coef[0];
}

void Delay::feed(float input) {
	_buffer[_writeptr] = input;
}

void Delay::advance() {
	_writeptr++;
	_writeptr *= _writeptr < _size;
}