#ifndef _PLAYER_HEADER_DEFINITION
#define _PLAYER_HEADER_DEFINITION

#include "global.h"
#include "audio.h"
#include "parse.h"
#include "voice.h"
#include "sequences.h"

namespace PLAYER {
using namespace SEQUENCES;
using namespace VOICE;
using namespace PARAMETER;
using std::string;

typedef enum {
	OSC_PLAY = 0,
	OSC_NEXT = 1,
	OSC_ERROR
} OSC_ENUM;

const ParseMap<OSC_ENUM> OSCMap = { 
	{"PLAY", OSC_PLAY},
	{"NEXT", OSC_NEXT},
};

class Metronome {
	Audio _current;
	const Clock &_clock;
	Pulse *_voice[2];
	Pulse *_active = nullptr;
	OscCallback _oscOutput;
	
	public:
	Metronome(const Clock & sampclock, const OscCallback oscOutput);
	~Metronome() {
		delete _voice[0];
		delete _voice[1];
	}
	const Audio & process();
};

class PlayerNode {
	public:
	PlayerNode(): _next(nullptr) {}
	PlayerNode(PlayerNode *next): _next(next) {}
	PlayerNode *getNext() { return _next; }
	void setNext(PlayerNode *next) { _next = next; }
	
	protected:
	PlayerNode *_next;
};

class Player : public PlayerNode {
	const string _id;
	const SequenceManager &_seqManager;
	const Clock &_clock;
	Audio _current;
	
	OscCallback _oscOutput;
	uchar _seq = 0;
	
	bool _isPlaying = false;
	bool _isQueued = false;
	
	ParameterManager *_paramManager;
	ParameterInt *_octave;
	ParameterFlt *_lfoFreq;
	
	Sequencer *_seqr;
	Voice *_voice[2];
	Voice *_active;
	LFO *_lfo;
	
	// PRIVATE MEMBER FUNCTIONS //
	void newNote(Tick event);
	void switchSequence();
	
	public:
	Player(const string &id, const SequenceManager &seqManager, const ParameterLoader &presets, const Clock &sampClock, const OscCallback oscOutput);
	~Player(void) {
		delete _paramManager;
		delete _seqr;
		delete _voice[0];
		delete _voice[1];
	}
	
	const Audio & process(void);
	bool command(const string, float value = 0.0f, const string &attribute = "");
	void off();
	void reset();
	
	Player * getNext(void) const { return static_cast<Player*>(_next); }
	const string & getID(void) const { return _id; }
	const Audio & getCurrent(void) { return _current; }
};

class PlayerManager {
	typedef struct PlayerFactory {
		static Player *generatePlayer(const string &id, const SequenceManager &seqManager, const ParameterLoader &presets, const Clock &sampClock, const OscCallback oscOutput)
		{ 
			return new Player(id, seqManager, presets, sampClock, oscOutput);
		}
	} PlayerFactory;
	
	class PlayerList : public PlayerNode {
		public:
		Player *getNext() {
			return static_cast<Player*>(_next);
		}
		~PlayerList(void) {
		    PlayerNode *current = _next;
		    PlayerNode *next;
		    while (current != nullptr) {
		        next = current->getNext();
		        delete current;
		        current = next;
		    }
		}
	};
	
	const SequenceManager *_seqManager;
	const ParameterLoader *_presets;
	Clock *_clock;
	Metronome *_metronome;
	
	PlayerList *_players;
	PlayerFactory *_factory;
	Audio _current;
	OscCallback _oscOutput;
	uchar _total;
	
	public:
	PlayerManager(const OscCallback oscOutput);
	~PlayerManager(void) {
		delete _seqManager;
		delete _presets;
		delete _metronome;
		delete _clock;
		delete _players;
		delete _factory;
	}
	
	uint create(const string &id);
	uint destroy(const string &id);
	const Audio & process(float clicklvl);
	
	void control(const string &id, const string &command, float value = 0.0f, const string &attribute = "");
	
	void play(void);
	void play(bool status);
	bool isPlaying(void) { return _clock->play(); }
	
	void reset(void);
	
	uint getTotal(void);
	const Audio & getCurrent(void) { return _current; }
	string &dumpPlayers(string &out);
	bool newBeat(void) const { return _clock->getTickCount() == 0; }
};
}
#endif