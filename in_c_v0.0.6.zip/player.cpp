#include "player.h"
using namespace PLAYER;

//~~~~~~~~~~~//
// METRONOME //
//~~~~~~~~~~~//

Metronome::Metronome(const Clock & sampclock, const OscCallback oscOutput):
_clock(sampclock), _oscOutput(oscOutput) {
	_voice[0] = new Pulse(0);
	_voice[1] = new Pulse(1);
}

const Audio & Metronome::process(void) {
	if (_clock.isNewBeat() && _clock.play()) {
		if (_active) {
			bool selected = !_active->getIndex();
			_active->kill();
			_active = _voice[selected];
		} else {
			_active = _voice[0];
		}
		_active->trigger(72);
		(*_oscOutput)("/pulse", "null", 0);
	}
	
	_current.reset();
	if (_active) _active = _active->isActive() ? _active : nullptr;
	else return _current;
	
	_current += _voice[0]->process();
	_current += _voice[1]->process();
	
	return _current *= 0.5;
}

/*~~~~~~~~*/
/* PLAYER */
/*~~~~~~~~*/

Player::Player(const string &id, const SequenceManager &seqManager, const ParameterLoader &presets, const Clock &sampClock, const OscCallback oscOutput):
_id(id), _seqManager(seqManager), _clock(sampClock), _oscOutput(oscOutput) {
	_octave = 0;
	_active = nullptr;
	
	_paramManager = new ParameterManager(presets);
	_seqr = new Sequencer(_seqManager.getSequence(_seq));
	_lfoFreq = new ParameterFlt(_paramManager->getParameter(PARAM_LFOFREQ));
	_lfo = new LFO;
	_octave = new ParameterInt(_paramManager->getParameter(PARAM_OCTAVE), 1, _lfo->getPointer());
	
	_voice[0] = new Voice(*_paramManager, _lfo, 0);
	_voice[1] = new Voice(*_paramManager, _lfo, 1);
}

const Audio & Player::process(void) {
	_current.reset();
	_paramManager->process();
	_lfo->process(_lfoFreq->getFloat(true));
	
	if(_clock.isNewBeat()) {
		if (_isPlaying && !_isQueued) off();
		_isPlaying = _isQueued;
	}
	
	bool isLast = _seq > 52;
	if(_clock.isNewTick() && _clock.play() && _isPlaying) {
		if(!_seqr->getIndex()) {
			if (isLast) {
				_seq = 0;
				_isPlaying = false;
				_isQueued = false;
			}
			(*_oscOutput)("/newseq", _id, 1, (float)_seq);
			_seqr->setSequence(_seqManager.getSequence(_seq));
		}
		if(!isLast) {
			Tick event = _seqr->getTick();
			if(event) newNote(event);
			_seqr->nextTick();
		}
	}
	_current += _voice[0]->process();
	_current += _voice[1]->process();
	return _current;
}

bool Player::command(const string command, float value, const string &attribute) {
	switch(ParseString<OSC_ENUM>(command, OSCMap, OSC_ERROR)) {
		case OSC_NEXT: {
			_seq += _isPlaying;
			return true;
		}
		case OSC_PLAY: {
			_isQueued = (bool)value;
			return true;
		}
		default:
		case OSC_ERROR: {
			return _paramManager->setParameter(command, value, attribute);
		}
	}
}

void Player::reset(void) {
	_seq = 0;
	_isPlaying = false;
	_isQueued = false;
	_seqr->setSequence(_seqManager.getSequence(0));
	_seqr->setIndex(0);
}

void Player::off(void) {
	_voice[0]->noteOff();
	_voice[1]->noteOff();
	_active = nullptr;
}

void Player::newNote(Event * event) {
	uchar index = 0;
	uchar note = event->note + (_octave->getInt(true) * 12);
	uchar vel = event->vel;
	if (event->type && vel) {
		if (_active) {
			_active->noteOff(true);
			index = !(_active->getIndex());
		}
		_active = _voice[index];
		_active->noteOn(note, vel);
		(*_oscOutput)("/note", _id, 3,
			(float)note,
			(float)vel * MIDI_DIVIDER * _active->getLevel(),
			_lfo->getCurrent()
		);
	}
	else if (_active) {
		_active->noteOff();
		_active = nullptr;
		//(*_oscOutput)("/note", _id, 1, 0.0f);
	}
}

/*~~~~~~~~~~~~~~~~*/
/* PLAYER MANAGER */
/*~~~~~~~~~~~~~~~~*/

PlayerManager::PlayerManager(const OscCallback oscOutput): _oscOutput(oscOutput) {
	string file = "data/defaults.json";
	_seqManager = new SEQUENCES::SequenceManager;
	_presets = new PARAMETER::ParameterLoader(file);
	_clock = new SEQUENCES::Clock(*_seqManager);
	_metronome = new Metronome(*_clock, _oscOutput);
	_players = new PlayerList;
	_factory = new PlayerFactory;
}

const Audio & PlayerManager::process(float clicklvl) {
	_clock->process();						// iterate clock
	_current.reset();						// reset active signal to zero
	_current += _metronome->process();		// process metronome, add to active signal
	_current *= clicklvl;
	Player *selected = _players->getNext(); // get first player
	while(selected) {						// loop this while not null
		_current += selected->process();	// process player and add to active current
		selected = selected->getNext(); 	// get next player
	}
	
	return _current;
}

uint PlayerManager::create(const string &id) {
	PlayerNode *prev = _players;
	PlayerNode *selected = _players->getNext();
	while(selected) {
		prev = selected;
		selected = selected->getNext();
	}
	prev->setNext(_factory->generatePlayer(id, *_seqManager, *_presets, *_clock, _oscOutput));
	_total++;
	
	return _total;
}

uint PlayerManager::destroy(const string &id) {
	Player *selected = _players->getNext();
	if (!selected) return _total;
	
	PlayerNode *prev = _players;
	while(selected && selected->getID() != id) {
		prev = selected;
		selected = selected->getNext();
	}
	
	if (selected) {
		prev->setNext(selected->getNext());
		delete selected;
		_total--;
	}
	
	return _total;
}

void PlayerManager::control(const string &id, const string &command, float value, const string &attribute) {
	Player *selected = _players->getNext();
	while(selected) {
		if(selected->getID() == id) {
			if(!selected->command(command, value, attribute) && PRINT_ON) {
				rt_printf("Error: %s sent %s which is not a valid command.\n", id.c_str(), command.c_str());
			};
			return;
		}
		else selected = selected->getNext();
	}
	if (!selected && PRINT_ON) {
		rt_printf("Error: %s is not a valid ID.\n", id.c_str());
	}
}

void PlayerManager::play(void) {
	bool current = _clock->play();
	play(!current);
}

void PlayerManager::play(bool status) {
	if (!status) {
		Player *selected = _players->getNext();
		while (selected) {
			selected->off();
			selected = selected->getNext();
		}
	}
	_clock->play(status);
}

void PlayerManager::reset(void) {
	Player *selected = _players->getNext();
	while(selected)	{
		selected->off();
		selected->reset();
		selected = selected->getNext();
	}
	_clock->play(false);
}

uint PlayerManager::getTotal(void) { 
	return _total;
}

string & PlayerManager::dumpPlayers(string &out) {
	out = "";
	Player *selected = _players->getNext();
	while(selected)	{
		out += selected->getID();
		selected = selected->getNext();
	}
	return out;
}