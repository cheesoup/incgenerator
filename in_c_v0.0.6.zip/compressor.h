#ifndef _COMPRESSOR_HEADER_DEFINITION
#define _COMPRESSOR_HEADER_DEFINITION

#include "global.h"
#include "audio.h"
#include "dsp.h"

namespace MASTER {
class Compressor {
	typedef enum COMP_ENUM {
		COMP_ATK = 0,
		COMP_REL = 1,
		COMP_THRESH = 2,
		COMP_SLOPE = 3,
		COMP_PREGAIN = 4,
		COMP_POSTGAIN = 5
	} COMP_ENUM;
	float _parameters[6];
	
	Audio _current;
	const uint _rmsSize, _bufferSize;
	const float _oneoverSize;
	
	float *_buffer[2];
	uint _writeptr;
	
	constexpr float sqravg(float x0, float x1) const {
		return (x0 * x0 + x1 * x1) * 0.5f;
	}
	
	inline float calculateRMS(float left, float right);
	inline float applyEnvelope(float x);
	
	public:
	Compressor(uint rmsSize, uint lookahead);
	const Audio & process(const Audio &input);
	const Audio & getCurrent() { return _current; }
	void setParameter(COMP_ENUM param, float value);
};
}

#endif