var playing = false;

function buildControls() {
	// Get Controls div.
	controls = document.getElementById('Controls');
	
	// Create container for head controls
	let head = createDiv();
	head.parent(controls);
	head.id("Head");
	
	// Create head controls
	let play = createButton('Play');
	play.parent(head);
	play.mousePressed(playCB);
	
	let next = createButton('Next');
	next.parent(head);
	next.mousePressed(nextCB);
	
	let tail = createDiv();
	tail.parent(controls);
	tail.id("Tail");

	synth = createDiv();
	synth.parent(tail);
	synth.id("Synth");
	synth.class("page");
	
	wave = createDiv();
	wave.parent(tail);
	wave.id("Wave");
	wave.class("page");
	
	adsr = createDiv();
	adsr.parent(tail);
	adsr.id("ADSR");
	adsr.class("page");
	
	let hide = createButton('Hide');
	hide.mousePressed(function() { displayControl(""); });
	hide.parent(head);

	let showSynth = createButton('Synth');
	showSynth.mousePressed(function() { displayControl("SYNTH"); });
	showSynth.parent(head);
	let showWave = createButton('Wave');
	showWave.mousePressed(function() { displayControl("WAVE"); });
	showWave.parent(head);
	let showADSR = createButton('ADSR');
	showADSR.mousePressed(function() { displayControl("ADSR"); });
	showADSR.parent(head);
	
	// Create sliders + mod
	for (let i = 0; i < presets.length; i++) {
		var parameter = createDiv();
		parameter.class("parameter");
		switch(presets[i].page) {
			case "SYNTH":
				parameter.parent(synth);
				break;
			case "WAVE":
				parameter.parent(wave);
				break;
			case "ADSR":
				parameter.parent(adsr);
				break;
		}
		
		var name = createDiv(presets[i].name);
		name.parent(parameter);
		name.class(presets[i].name + " " + "name");
		

		var userlabel = createDiv("Value");
		userlabel.parent(parameter);
		userlabel.class(presets[i].name + " " + "label");
		
		var user;
		if (presets[i].type === "INT") {
			user = createSlider(presets[i].min, presets[i].max, presets[i].value);
			user.input(slideCB);
		} else {
			user = createSlider(0, 255, presets[i].value * 255);
			user.input(slideCB);
		}
		user.parent(parameter);
		user.class(presets[i].name + " user");
		
		if (presets[i].mod_options.length > 0) {
			var modlabel = createDiv("Mod");
			modlabel.parent(parameter);
			modlabel.class(presets[i].name + " label");
		
			var mod = createSlider(0, 255, presets[i].mod * 255);
			mod.input(slideCB);
			mod.parent(parameter);
			mod.class(presets[i].name + " mod");
		}
		if (presets[i].mod_options.length > 1) {
			var modsellabel = createDiv("Source");
			modsellabel.parent(parameter);
			modsellabel.class(presets[i].name + " label");
			
			var modsel = createSelect();
			modsel.class(presets[i].name + " " + " input modsel");
			for (let j = 0; j < presets[i].mod_options.length; j++) {
				modsel.option(presets[i].mod_options[j]);
			}
			modsel.input(modselCB);
			modsel.parent(parameter);
		}
	}
}

function playCB() {
	playing = !playing;
	controlChange("PLAY", Number(playing), "null");
}

function nextCB() {
	controlChange("NEXT", 0, "null");
}

function slideCB(input) { 
	let classes = input.target.className.split(' ');
	controlChange(classes[0], input.target.value / 255, classes[1]);
}

function modselCB(input) {
	let classes = input.target.className.split(' ');
	controlChange(classes[0], input.target.selectedIndex + 1, "modsel");
}