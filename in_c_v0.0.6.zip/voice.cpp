#include "voice.h"
using namespace VOICE;

//~~~~~~~//
// Voice //
//~~~~~~~//

Voice::Voice(const ParameterManager &paramManager, const LFO * lfo, uchar index):
_index(index), _freq(0.0f), _delta(0.0f), _vel(0.0f) {
	_osc	= new BasicWaves;	
	_subosc	= new IIRSine;
	_env	= new Envelope;
	_click	= new Click;
	_pluck	= new Delay(0.1f);
	_damp	= new OnePole;
	_diff	= new AllPass;
	_hpf	= new OnePole(20.0f);
	
	_atk	= new ParameterFlt(paramManager.getParameter(PARAM_ATTACK), 2, lfo->getPointer());
	_dec	= new ParameterFlt(paramManager.getParameter(PARAM_DECAY), 2, lfo->getPointer());
	_sus	= new ParameterFlt(paramManager.getParameter(PARAM_SUSTAIN), 2, lfo->getPointer());
	_rel	= new ParameterFlt(paramManager.getParameter(PARAM_RELEASE), 2, lfo->getPointer());
	_lvl	= new ParameterFlt(paramManager.getParameter(PARAM_LEVEL), 2, lfo->getPointer(), _env->getPointer());
	_pan	= new ParameterFlt(paramManager.getParameter(PARAM_PAN), 2, lfo->getPointer(), _env->getPointer());
	_pw 	= new ParameterFlt(paramManager.getParameter(PARAM_PW), 2, lfo->getPointer(), _env->getPointer());
	_shape	= new ParameterFlt(paramManager.getParameter(PARAM_SHAPE), 2, lfo->getPointer(), _env->getPointer());
	_bright = new ParameterFlt(paramManager.getParameter(PARAM_BRIGHT), 2, lfo->getPointer(), _env->getPointer());
	_sub	= new ParameterFlt(paramManager.getParameter(PARAM_SUB), 2, lfo->getPointer(), _env->getPointer());
}

const Audio & Voice::process() {
	_current.reset();
	if (_env->getStage() == ENVSTAGE_ENUM::ENV_OFF) return _current;
	float out = 0.0f;
	float env = _env->process();
	float click = _click->process();
	
	float shape = _shape->getFloat(true);
	
	out = _osc->process(_delta, _pw->getFloat(true) * 0.9f + 0.05f, shape);
	out = morph(out, _osc->getPhase(), _bright->getFloat(true));
	out = DSP::LINTERPOLATE(out, _subosc->process(), _sub->getFloat(true) * 0.5);
	out *= env;
	
	float noise = (
        _click->getStage() != CLICKSTAGE_ENUM::CLICK_OFF ?
        (DSP::RAND() * 2.0f - 1.0f) * click : 0.0f
    );
    float karp = 0.0f;
    _damp->process(karp);
    _diff->process(karp, 0.5f);
    _pluck->feed(noise + karp * _vel);
    _pluck->advance();
    out += karp;
    
	float lvl = _lvl->getFloat(true);
	out = DSP::SIGMOID(out * lvl * lvl * 2.0f);
	out -= _hpf->process(out);
	
	float pan = _pan->getFloat(true) * 0.5;
	_current[CHANNEL_LEFT] = out * DSP::SIN2_NONORMAL(pan - 0.5f);
	_current[CHANNEL_RIGHT] = out * DSP::SIN2_NONORMAL(pan);
	return _current;
}

void Voice::noteOn(uint note, uint vel) {
	if (!vel) noteOff();
	else {
		_freq = DSP::MTOF(note);
		_delta = _freq * *ONE_OVER_SAMPLERATE;
		_vel = DSP::MIDITOLINAMP(vel);
		_period = DSP::RECIPROCAL(_freq * 2.0f);
		
		_subosc->setFreq(_freq * 0.5f);
		_damp->setCutoff(_freq * 2.0f);
		_env->trigger(
			_atk->getFloat(true), _dec->getFloat(true),
			_sus->getFloat(true), _rel->getFloat(true),
			_vel
		);
		_click->trigger(_atk->getFloat() * 0.2f, _rel->getFloat() * 0.2f, _vel);
		
		if (_env->getStage() == ENVSTAGE_ENUM::ENV_OFF) {
			_osc->setPhase(DSP::RAND());
			_subosc->reset();
		}
	}
}

void Voice::noteOff(bool kill) {
	if (kill) _click->kill();
	_env->release(kill);
	_vel = 0.0f;
}

float Voice::morph(float input, float phase, float brightness) {
	// Convert shapePhase to asin of shapePhase
	input = DSP::ASIN(input);
	
	// Wrap phase as a triangle wave between -0.5 and 0.5
	phase = phase + 0.5f;
	phase = DSP::WRAP(phase);
	phase -= 0.5f;
	phase = DSP::ABS(phase);
	
	// Normalize asin(shapePhase) to 1rad/period.
	// Integrate into wrapped phase and shift values to
	// return the cosine from SIN.
	phase = (phase + ((-0.159155f * input - phase + 0.25f) * brightness)) * 2.0f - 0.5f;
	return DSP::SIN2_NONORMAL(phase);
}

//~~~~~~~//
// Pulse //
//~~~~~~~//

Pulse::Pulse(uchar index) {
	_index = index;
	
	_osc = new IIRSine;
	_mod = new IIRSine(0.03f);
	_env = new Click;
	_click = new Click(0.05f, 0.166f);
	_pluck = new Delay(0.1f);
	_damp = new OnePole;
	_diff = new AllPass;
}

const Audio & Pulse::process() {
	_current.reset();
	float out = 0.0f;	
	float env = _env->process();
	float click = _click->process();
	out = _osc->process() * env;
	
	float noise = (
		_click->getStage() != CLICKSTAGE_ENUM::CLICK_OFF ?
		(DSP::RAND() * 2.0f - 1.0f) * click : 0.0f
	);
	float karp = _pluck->tap(_period);
	_damp->process(karp);
	_diff->process(karp, _mod->process() * 0.25f + 0.5f);
	_pluck->feed(noise + karp * 0.9f);
	_pluck->advance();
	out += karp;
	
	out = DSP::SIGMOID(out) * SINQTRPI;
	_current[CHANNEL_LEFT] = out;
	_current[CHANNEL_RIGHT] = out;
	
	return _current;
}

void Pulse::trigger(uchar note) {
	if (_click->getStage() == CLICKSTAGE_ENUM::CLICK_OFF)
		_osc->reset();
	float freq = DSP::MTOF((uint)note);
	
	_period = DSP::RECIPROCAL(freq * 2.0);
	_damp->setCutoff(freq);
	_osc->setFreq(freq);
	
	_env->trigger(0.05f, 0.5f, 0.75f);
	_click->trigger(0.01f, 0.03f, 0.5f);
}

void Pulse::kill() {
	_osc->setFreq(0.0f);
	_env->kill();
	_click->kill();
}


