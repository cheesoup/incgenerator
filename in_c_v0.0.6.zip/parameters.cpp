#include <fstream>
#include <codecvt>
#include <JSON.h>
#include "dsp.h"
#include "parameters.h"

using namespace PARAMETER;
using namespace DSP;

//~~~~~~~~~~~~~~~~~//
// ParameterLoader //
//~~~~~~~~~~~~~~~~~//

ParameterLoader::ParameterLoader(const std::string & filename) {
	printf("Loading default settings...\n");
	try {
		// Load JSON file into a single string for SimpleJSON to parse
		std::wifstream in(filename.c_str());
		std::wstring data = L"";
		std::wstring line;
		while (getline(in, line))
		{
			data += line;
			if (!in.eof()) data += L"\n";
		}
		
		// SimpleJSON magic
		JSONValue *value = JSON::Parse(data.c_str());
		JSONObject root = value->AsObject();
		
		// Grab array from JSONObject
		JSONArray array = root[L"presets"]->AsArray();
		for (unsigned int i = 0; i < array.size(); i++) {
			// Grab subobject within the array
			JSONObject sub = array[i]->AsObject();
			
			// Select index by converting JSON wstring to UTF8 to ENUM
			std::wstring_convert<std::codecvt_utf8<wchar_t>> name_converter;
			std::string name = name_converter.to_bytes(sub[L"name"]->AsString());
			std::string type = name_converter.to_bytes(sub[L"type"]->AsString());
			PARAM_ENUM select = ParseString<PARAM_ENUM>(name, ParameterMap, PARAM_ERROR);
			
			// Skip if Parameter selected is invalid
			if (select == PARAM_ERROR) {
				printf("ERROR: %s\n", name.c_str());
				printf("Invalid Parameter.\n");
				continue;
			}
			
			float mod = sub[L"mod_value"]->AsNumber();
			uchar modptr = sub[L"mod_ptr"]->AsNumber();
			
			if (type == "FLOAT") {
				// Get values
				float user = sub[L"value"]->AsNumber();
				_values[select] = new ValueFlt(user, mod, modptr);
				if (PRINT_ON) 
					printf("loading: %s\t value: %f\t mod: %f\t modptr: %d\n", name.c_str(), user, mod, modptr);
			} else if (type == "INT") {
				int user = sub[L"value"]->AsNumber(), min = sub[L"min"]->AsNumber(), max = sub[L"max"]->AsNumber();
				_values[select] = new ValueInt(min, max, user, mod, modptr);
				if (PRINT_ON) 
					printf("loading: %s\t value: %d\t mod: %f\t modptr: %d\n", name.c_str(), user, mod, modptr);
			} else {
				printf("ERROR: %s\n", name.c_str());
				printf("Invalid Parameter Type: %s\n", type.c_str());
				continue;
			}
		}
		printf("Default settings loaded successfully.\n");
	} catch (...) {	printf("ERROR: Could not read defaults.json\n"); }
	
	// Initialize inertia
	_steps = (int)(*SAMPLERATE * *INERTIA);
	_rsteps = 1.0f / (float)_steps;
}

void ParameterLoader::initialize(Value *values[PARAM_ERROR], uint &steps, float &rsteps) const {
	for (int i = 0; i < PARAM_ERROR; i++) {
		if (_values[i]->type == PARAMTYPE_ENUM::FLOAT) {
			values[i] = new ValueFlt(static_cast<ValueFlt*>(_values[i]));
		}
		else if (_values[i]->type == PARAMTYPE_ENUM::INT) {
			values[i] = new ValueInt(static_cast<ValueInt*>(_values[i]));
		}
	}
	steps = _steps;
	rsteps = _rsteps;
}

//~~~~~~~~~~~~~~~~~~//
// ParameterManager //
//~~~~~~~~~~~~~~~~~~//

void ParameterManager::process() {
	for (int i = 0; i < PARAM_ERROR; i++) {
		if (_values[i]->count) {
			ValueFlt *selected = static_cast<ValueFlt*>(_values[i]);
			selected->count--;
		}
	}
}

bool ParameterManager::setParameter(const std::string &command, float value, const std::string &attribute) {
	PARAM_ENUM param = ParseString<PARAM_ENUM>(command, ParameterMap, PARAM_ERROR);
	if (param == PARAM_ERROR || attribute == "") return false;
	else if (attribute == "mod") {
		_values[param]->mod = DSP::CLIP(value);
		return true;
	}
	else if (attribute == "modsel") {
		_values[param]->modsel = (uint)DSP::ABS(value);
		return true;
	}
	else if (attribute == "user") {
		if (_values[param]->type == PARAMTYPE_ENUM::FLOAT) {
			ValueFlt *selected = static_cast<ValueFlt*>(_values[param]);
			value = DSP::CLIP(value);
			selected->delta = (value - selected->current) * _rsteps;
			selected->user = value;
			return true;
		} 
		if (_values[param]->type == PARAMTYPE_ENUM::INT) {
			ValueInt *selected = static_cast<ValueInt*>(_values[param]);
			selected->current = (int)DSP::CLIP(value * 255.0f, (float)selected->max, (float)selected->min);
			return true;
		}
	}
	return false;
}

//~~~~~~~~~~~//
// Parameter //
//~~~~~~~~~~~//

Parameter::Parameter(uint total):
_modtotal(total ? total + 1 : 0) {}

//CASLCUOLATPJATNK FUCKIPONG MOLDF

float Parameter::calculateMod(const Value *value) const {
	if (_mod == nullptr) return 0.0f;
	const uchar modsel = value->modsel * (value->modsel <= _modtotal);
	const float mod = *_mod[modsel] * (value->mod * 2.0f - 1.0f);
	return mod;
}

ParameterInt::ParameterInt(const Value *value, uint total, ...):
Parameter(total), _value(static_cast<const ValueInt*>(value))
{
	if (!_modtotal) _mod = nullptr; 
	else {
	    _mod = new float*[_modtotal];
	    _mod[0] = new float{ 0.0f };
	    
	    va_list args;
	    va_start(args, total);
	    if (total) {
		    for (int i = 1; i < total + 1; i++)
		    	_mod[i] = va_arg(args, float*);
	    }
	    va_end(args);
	}
}

void ParameterInt::process() {
	float mod = calculateMod(_value);
	bool dir = mod > 0;
	_current = _value->current;
	mod *= (float)(dir * (_value->max - _current) + !dir * (_current - _value->min));
	_current += (int)mod;
}

float ParameterInt::getFloat(bool recalculate) {
	if (recalculate) process();
	return (float)_current * MIDI_DIVIDER;
}

int ParameterInt::getInt(bool recalculate) {
	if (recalculate) process();
	return _current;
}

ParameterFlt::ParameterFlt(const Value *value, uint total, ...):
Parameter(total), _value(static_cast<const ValueFlt*>(value))
{	
	if (!_modtotal) _mod = nullptr; 
	else {
	    _mod = new float*[_modtotal];
	    _mod[0] = new float{ 0.0f };
	    
	    va_list args;
	    va_start(args, total);
	    if (total) {
		    for (int i = 1; i < total + 1; i++)
		    	_mod[i] = va_arg(args, float*);
	    }
	    va_end(args);
	}
}

void ParameterFlt::process() {
	float mod = calculateMod(_value);
	_current = _value->user - _value->delta * _value->count;
	_current += mod * _current;
	DSP::CLIP(_current);
}


float ParameterFlt::getFloat(bool recalculate) {
	if (recalculate) process();
	return _current;
}

int ParameterFlt::getInt(bool recalculate) {
	if (recalculate) process();
	return (int)(_current * 127.0f);
}