#include <MidiFile.h>
#include "sequences.h"
using namespace SEQUENCES;

/*~~~~~~~~~~~~~~~~~~*/
/* SEQUENCE MANAGER */
/*~~~~~~~~~~~~~~~~~~*/

SequenceManager::SequenceManager() {
	const std::string filename = "data/In_C_tracksplit_qtrspeed.mid";
	smf::MidiFile midifile;
	uint trackTotal;
	printf("Loading MIDI file...\n");
	try {
		// Read MIDI file and get the track count
		midifile.read(filename);
		trackTotal = midifile.getTrackCount();
		_ticksPerBeat = midifile.getTicksPerQuarterNote();
		_totalSequences = 0;
		
		// Check each track for its length.
		// This could probably be better implemented as a link list.
		for (uint trackIndex = 0; trackIndex < trackTotal; trackIndex++) {
			if (midifile[trackIndex][midifile[trackIndex].size()-1].tick) _totalSequences++;
		}
		
		// Initialize array of pointers based on how many tracks have a length greater than 0.
		_sequences = new Sequence*[_totalSequences] { nullptr };
		
		// Translate MidiEvent to an array of pointers of type Event.
		// Absence of a pointer means nothing happens.
		for(uint trackIndex = 0, sequenceIndex = 0; trackIndex < trackTotal; trackIndex++) {
			// Re-obtain length of track
			uint length = midifile[trackIndex][midifile[trackIndex].size()-1].tick;
			
			// If length = 0, skip track
			if (!length) continue;
			
			// Initialize an array within the array of Sequence pointers.
			// Sequence is a container class which manages an array of normally null Event type pointers.
			_sequences[sequenceIndex] = new Sequence(length); 
			
			// Activate pointers within the Sequence based on MIDI events
			for (int eventIndex = 0; eventIndex < midifile[trackIndex].size(); eventIndex++) {
				// Get MIDI event's tick value
				uint tickIndex = midifile[trackIndex][eventIndex].tick % length;
				// Check for note on and note off messages
				// If note on, declare pointer indexed at the event's tick value as a note on
				if (midifile[trackIndex][eventIndex].isNoteOn()) {
					_sequences[sequenceIndex]->setTick(tickIndex, true, midifile[trackIndex][eventIndex][1], midifile[trackIndex][eventIndex][2]);
				}
				// If note off, declare pointer indexed at the event's tick value as a note off
				// only if it hasn't already been written as note on.
				else if (midifile[trackIndex][eventIndex].isNoteOff() && !_sequences[sequenceIndex]->getTick(tickIndex)) {
					_sequences[sequenceIndex]->setTick(tickIndex, false, midifile[trackIndex][eventIndex][1], 0);
				}
			}
			sequenceIndex++;
		}
		printf("MIDI file loaded successfully.\n");
	}
	catch (...) {
		printf("ERROR: Failed to load MIDI file");
	}
}

SequenceManager::~SequenceManager() {
	for(uint sequenceIndex = 0; sequenceIndex < _totalSequences; sequenceIndex++) delete _sequences[sequenceIndex];
}

/*~~~~~~~*/
/* CLOCK */
/*~~~~~~~*/

void Clock::process() {
	if (_play) {
		_sampleCount++;
		
		bool reset = _sampleCount >= _samplesPerTick;
		_tickCount += reset;
		_sampleCount *= !reset;
		_tickCount *= _tickCount < _ticksPerBeat;
	}
}

void Clock::setTempo(float bpm) {
	bpm *= 4.0f;
	bpm /= 60.0f;			// convert to beats per second
	bpm = *SAMPLERATE / bpm;	// calculate samples per beat
	_samplesPerTick = (uint)(bpm / (float)_seqManager.getTicksPerBeat());
	if (PRINT_ON) {
		rt_printf("Ticks Per Beat: %d\n", _seqManager.getTicksPerBeat());
		rt_printf("Samples Per Tick: %d\n", _samplesPerTick);
		rt_printf("Samples Per Beat: %d\n", _seqManager.getTicksPerBeat() * _samplesPerTick);
	}
}

/*~~~~~~~~~~~*/
/* SEQUENCER */
/*~~~~~~~~~~~*/

Tick Sequencer::getTick() {
	return _seq->getTick(_currentTickIndex);
}

void Sequencer::nextTick() {
	_currentTickIndex++;
	_currentTickIndex *= _currentTickIndex < _seq->length();
}

void Sequencer::setSequence(const Sequence *seq) {
	_seq = const_cast<Sequence*>(seq);
}

uint Sequencer::getIndex() { 
	return _currentTickIndex;
}

void Sequencer::setIndex(uint index) {
	_currentTickIndex = index;
}