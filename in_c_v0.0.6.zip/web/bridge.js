var fs = require('fs');

// Ports and Addresses
var sendPort = 7562;
var receivePort = 7563;
var localIP = '127.0.0.1';
var server_ready = false;

/*------*/
/* HTTP */
/*------*/
var http = require('http');
var url = require('url');
var path = require('path');
var server = http.createServer(handleRequest);

server.listen(8080);
console.log('NODE: Server started on port 8080');

function handleRequest(req, res) {
	var pathname = req.url;
	if (pathname == '/') pathname = '/index.html';
	var ext = path.extname(pathname);
	var typeExt = {
		'.html': 'text/html',
		'.js': 'text/javascript',
		'.css': 'text/css'
	};
	var contentType = typeExt[ext] || 'text/plain';

	fs.readFile(__dirname + pathname,
		function (err, data) {
			if (err) {
				res.writeHead(500);
				return res.end('Error loading ' + pathname);
			}
			res.writeHead(200, { 'Content-Type': contentType });
			res.end(data);
		}
	);
}

/*-----------*/
/* Websocket */
/*-----------*/

var websocket = require('socket.io')(server, {
	cors: {
		origin: "*",
		methods: ["GET", "POST"],
		allowedHeaders: ["test"],
		credentials: true
  	}
});

websocket.on('connection', function (socket) {
	// On Connect
	if (server_ready) {
		sendOSC(osc.toBuffer(
			{ address : '/register', args: [socket.id, true] }
		));
	} else {
		websocket.to(socket).emit("error", {
			error : "Server isn't ready. Try refreshing in about five seconds."
		});
	}
	// On Control Change
	socket.on('control', function(data) {
		if (server_ready) {
			let cmd = data.command;
			let attr = data.attribute;
			let val = data.value;
			//console.log(data);
			updatePlayerValues(socket.id, cmd, val, attr);
			sendOSC(osc.toBuffer({ address : '/control', args: [socket.id, cmd, attr, val] }));
			websocket.emit("control", { id: socket.id, command: cmd, attribute: attr, value: val });
		}
	});
	// On Disconnect
	socket.on('disconnect', function() {
		destroyPlayer(socket.id);
		if (server_ready) {
			sendOSC(osc.toBuffer({ address : '/register', args: [socket.id, false] }));
			console.log("NODE: User disconnected.");
		}
	});
});

/*--------------*/
/* OSC over UDP */
/*--------------*/

var osc = require('osc-min');
var dgram = require('dgram');
var udpsocket = dgram.createSocket('udp4', function(buffer, rinfo) {
	var error;
	try {
		var msg = osc.fromBuffer(buffer);
		if (msg.oscType == 'message') parseOSC(msg);
		else if (msg.elements) {
			for (let element of msg.elements) parseOSC(msg);
		}
	} catch (error) { return console.log("NODE: OSC packet error: " + error); }
});
udpsocket.bind(receivePort);

function check_server() {
	sendOSC(osc.toBuffer({ address : '/ready' }));
}

function sendOSC(msg) {
	udpsocket.send(msg, 0, msg.length, sendPort, localIP, function(err) {
		if (err) console.log(err);
	});
}

function parseOSC(msg) {
	let address = msg.address.split('/');
	let data = {};
	if (!address || !address.length || address.length < 2) {
		console.log('NODE: Bad OSC address: ', address);
		return;
	}
	switch(address[1]) {
		case 'ready':
			console.log("NODE: Server is ready.");
			server_ready = true;
			break;
		case 'confirm':
			if (msg.args[1].value) {
				createPlayer(msg.args[0].value);
				websocket.to(msg.args[0].value).emit(address[1], playerlist);
				updatePlayerList(msg.args[0].value, true);
				console.log("NODE: We have a new client: " + msg.args[0].value);
			}
			else {
				data = { error : "Server is currently busy." };
				websocket.to(msg.args[0].value).emit("error", data);
			}
			break;
		case 'note':
			if (msg.args.length > 1) {
				data = {
					id: msg.args[0].value,
					note: msg.args[1].value,
					vel: msg.args[2].value,
					lfo: msg.args[3].value
				};
			} else 	data = { id: msg.args[0].value };
			websocket.emit(address[1], data);
			break;
		case 'pulse':
			websocket.emit(address[1]);
			break;
		case 'newseq':
			data = {
				id: msg.args[0],
				sequence: msg.args[1].value	
			};
			websocket.emit(address[1], data);
			break;
		default:
			var print = "";
			for (let i = 0; i < msg.args.length; i++) {
				print += ("arg[" + i + "]: " + msg.args[i].value + ". ");
			}
			console.log("NODE: Message addressed with " + address[1] + " received with " + msg.args.length + " arguments. " + print);
			break;
	}
}


var presets = [];
var playerlist = [];

fs.readFile(__dirname + '/js/defaults.json', 'utf8' , (err, data) => {
	if (err) { console.error(err); return; }
	let presets_json = JSON.parse(data);
	for (let i = 0; i < presets_json.presets.length; i++) {
		let parameter = { name: presets_json.presets[i].name, value: presets_json.presets[i].value, mod_value: presets_json.presets[i].mod_value };
		presets.push(parameter);
	}
});

function updatePlayerList(name, onoff) {
	let data = { id: name,	status: onoff }
	websocket.emit("playerlist", data);
}

function updatePlayerValues(name, parameter, value, attribute) {
	let selectedplayer = playerlist.find(o => o.id === name);
	if (selectedplayer) {
		let selectedparameter = selectedplayer.settings.find(o => o.name === parameter)
		if (selectedparameter) {
			switch(attribute) {
				case "user":
					selectedparameter.value = value;
					break;
				case "mod":
					selectedparameter.mod_value = value;
					break;
				default:
					break;
			}
		}
	}
	
	for (let i = 0; i < playerlist.length; i++) {
		if (playerlist[i].id === name) {
			for (let j = 0; j < playerlist[i].settings.length; j++) {
				if (parameter === playerlist[i].settings[j].name) {
					playerlist[i].settings[j].value = value;
					return;
				}
			}
		}
	}
}

function createPlayer(name) {
	let player = { id: name, settings: presets }
	playerlist.push(player);
}

function destroyPlayer(name) {
	for (let i = 0; i < playerlist.length; i++) {
		let deleted = playerlist[i];
		if (playerlist[i].id === name) {
			playerlist.splice(deleted, 1);
			updatePlayerList(name, false);
			return;
		}
	}
}