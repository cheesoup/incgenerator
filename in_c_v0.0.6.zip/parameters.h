#ifndef _PARAMETER_HEADER_DEFINITION
#define _PARAMETER_HEADER_DEFINITION

#include "global.h"
#include "parse.h"

namespace PARAMETER {
using std::string;

enum class PARAMTYPE_ENUM { FLOAT, INT };

typedef enum {
	PARAM_LEVEL		= 0,
	PARAM_PAN		= 1,
	PARAM_PW		= 2,
	PARAM_SHAPE		= 3,
	PARAM_BRIGHT	= 4,
	PARAM_SUB		= 5,
	PARAM_ATTACK	= 6,
	PARAM_DECAY		= 7,
	PARAM_SUSTAIN	= 8,
	PARAM_RELEASE	= 9,
	PARAM_OCTAVE	= 10,
	PARAM_LFOFREQ	= 11,
	PARAM_ERROR		= 12
} PARAM_ENUM;

const ParseMap<PARAM_ENUM> ParameterMap = {
	{"LEVEL", PARAM_LEVEL},
	{"PAN", PARAM_PAN},
	{"PW", PARAM_PW},
	{"SHAPE", PARAM_SHAPE},
	{"BRIGHT", PARAM_BRIGHT},
	{"SUB", PARAM_SUB},
	{"ATTACK", PARAM_ATTACK},
	{"DECAY", PARAM_DECAY},
	{"SUSTAIN", PARAM_SUSTAIN},
	{"RELEASE", PARAM_RELEASE},
	{"OCTAVE", PARAM_OCTAVE},
	{"LFOFREQ", PARAM_LFOFREQ}
};

// Data structure of a parameter's value
// x[0] = User amt ; x[1] = LFO amt ; x[2] = ENV amt

class Value {
	public:
	~Value() {}
	float mod = 0.0f;
	uchar modsel = 0;
	uint count = 0;
	PARAMTYPE_ENUM type;
};

class ValueFlt : public Value {
	public:
	float current = 0.5, user = 0.5f, delta = 0.0f;
	
	ValueFlt(float value = 0.0f, float modulation = 0.5f, uchar modulator = 0):
	current(value), user(value)
	{
		type = PARAMTYPE_ENUM::FLOAT;
		mod = modulation;
		modsel = modulator;
	}
	
	ValueFlt(const ValueFlt * copy):
	current(copy->current), user(copy->user), delta(copy->delta)
	{
		type = PARAMTYPE_ENUM::FLOAT;
		mod = copy->mod;
		modsel = copy->modsel;
		count = copy->count;
	}
};

class ValueInt : public Value {
	public:
	const int min = 0, max = 1;
	int current = 0;
	
	ValueInt(int minimum = 0, int maximum = 1, int value = 0, float modulation = 0.5f, uchar modulator = 0):
	min(minimum), max(maximum), current(value)
	{
		type = PARAMTYPE_ENUM::INT;
		mod = modulation;
		modsel = modulator;
	}
	
	ValueInt(const ValueInt * copy):
	min(copy->min), max(copy->max), current(copy->current)
	{
		type = PARAMTYPE_ENUM::INT;
		mod = copy->mod;
		modsel = copy->modsel;
	}
};

class ParameterLoader {
	protected:
	Value *_values[PARAM_ERROR];
	uint _steps;
	float _rsteps;
	
	public:
	ParameterLoader() {}
	ParameterLoader(const string & filename);
	void initialize(Value *values[PARAM_ERROR], uint &steps, float &rsteps) const;
};

class ParameterManager : public ParameterLoader {
	public:
	ParameterManager(const ParameterLoader & presets) {
		presets.initialize(_values, _steps, _rsteps);
	}
	~ParameterManager() {
		for (int i = 0; i < PARAM_ERROR; i++) {
			delete _values[i];
		}
	}
	
	void process();
	bool setParameter(const string &command, float value, const string &attribute);
	const Value * getParameter(PARAM_ENUM param) const { return _values[param]; }
};

class Parameter {
	protected:
	const uchar _modtotal;
	float **_mod;
	virtual float calculateMod(const Value *value) const;
	virtual void process() {}
	
	public:
	Parameter(uint total = 0);
	virtual ~Parameter() { if (_mod) delete _mod[0]; }
	virtual float getFloat(bool recalculate = false) { return 0.0f; }
	virtual int getInt(bool recalculate = false) { return 0; }
	virtual float getMod() const { return 0.0f; }
	virtual uchar getModSel() const { return 0; }
	virtual uchar getModTotal() const { return _modtotal; }
};

class ParameterInt : public Parameter {
	const ValueInt *_value;
	int _current = 0;
	
	protected:
	void process();
	
	public:
	ParameterInt(const Value *value, uint total = 0, ...);
	float getFloat(bool recalculate = false);
	int getInt(bool recalculate = false);
	float getMod() const { return calculateMod(_value); }
	uchar getModSel() const { return _value->modsel; }
};

class ParameterFlt : public Parameter {
	const ValueFlt *_value;
	float _current = 0.0f;
	
	protected:
	void process();
	
	public:
	ParameterFlt(const Value *value, uint total = 0, ...);
	float getFloat(bool recalculate = false);
	int getInt(bool recalculate = false);
	float getMod() const { return calculateMod(_value); }
	uchar getModSel() const { return _value->modsel; }
};

}
#endif