#ifndef _FILTER_HEADER_DEFINITION
#define _FILTER_HEADER_DEFINITION

#include "global.h"
#include "dsp.h"

namespace DSP {
class Filter {
	protected:
	float *_buffer;
	
	public:
	Filter() {}
	virtual ~Filter() { delete _buffer; }
};

class OnePole : public Filter {
	float _coef;
	
	public:
	OnePole(float cutoff = 0.0f) {	
		_buffer = new float{};
		setCutoff(cutoff);
	}
	
	void setCutoff(float freq) {
		_coef = expf_neon(-2.0 * M_PI * freq * *ONE_OVER_SAMPLERATE);
	}
	
	float process(float input) {
		input = (1.0f - _coef) * input + _coef * *_buffer;
		*_buffer = input;
		return input;
	}
};

class AllPass : public Filter {
	public:
	AllPass() {	
		_buffer = new float{};
	}
	
	float process(float input, float coef = 0.0f) {
		float out = *_buffer + coef * input;
		*_buffer = out - input * coef;
		return out;
	}
};
}
#endif