#ifndef _OSCILLATOR_HEADER_DEFINITION
#define _OSCILLATOR_HEADER_DEFINITION
#include "global.h"
#include "dsp.h"

namespace VOICE { namespace OSCILLATOR {
// Recursive rilter based sine generator
// For statically shaped LFOs and Sub Oscillators.
class IIRSine {
	float coef = 0;
	float s[2] = { 0.5f, 0.0f };
	public:
	IIRSine(float freq = 0) {
		setFreq(freq);
	}
	void reset() {
		s[0] = 0.5f;
		s[1] = 0.0f;
	}
	void setFreq(float freq) {
		// needs somewhat accurate sine calc on set
		coef = 2.0f * sinf_neon(M_PI * freq * *ONE_OVER_SAMPLERATE);
	}
	float process() {
		s[0] = s[0] - coef * s[1];
		s[1] = s[1] + coef * s[0];
		
		float out = s[0];
		const float tmp = 1.5f - 0.5f * (s[1] * s[1] + s[0] * s[0]);
		s[0] *= tmp;
		s[1] *= tmp;
		
		return out;
	}
};

// Polynomial + phase counter based wave parent
// For phase based synthesis
class Oscillator {
	protected:
	float _phase;
	
	public:
	Oscillator(): _phase(0.0f) {}
	virtual ~Oscillator() {};
	
	virtual float process(float delta);
	virtual void setPhase(float p) { _phase = p; }
	virtual float getPhase(void) { return _phase; }
};


class BasicWaves: public Oscillator {
	using Oscillator::process;
	enum wave {
    	NOTHING = -1,
        PULSE = 0,
        EXPO,
        SAW
    };
	
	inline float pwPhase(float duty) {
		return _phase < duty ? _phase / (duty * 2.0f) : (_phase - duty) / (2.0f - duty * 2.0f) + 0.5f;
	}
	
	inline float polyBLEP(float p, float delta) {
		bool x1, x2 = false;
		float d = DSP::RECIPROCAL(delta);
		p += _phase;
		p = DSP::WRAP(p);
		
		x1 = p < delta;
		x2 = p > (1.0f - delta);
		if (!(x1 + x2)) return 0.0f;
		
		p = (float)x1 * (p * d) + (float)x2 * (p - 1.0f) * d;
		return (float)x1 * (p + p - p * p - 1.0f) + (float)x2 * (p + p + p * p + 1.0f);
	}
	
	public:
	float process(float delta) {
		float out = process(delta, 0.0f, 0.5f);
		return out;
	}
	float process(float delta, float mod, float pw);
};

}}
#endif