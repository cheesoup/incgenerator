#ifndef _PARSE_DEFINITION
#define _PARSE_DEFINITION

#include <string>
#include <unordered_map>

typedef void (*OscCallback)(const std::string &, const std::string &, uint, ...);

template <typename T>
using ParseMap = std::unordered_map<std::string, T>;

template <typename T>
inline T ParseString(const std::string &input, const ParseMap<T> &map, T error) {
	auto it = map.find(input);
	if (it != map.end()) return it->second;
	else return error;
}

#endif