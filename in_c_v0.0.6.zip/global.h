#ifndef _GLOBAL_HEADER_DEFINITION
#define _GLOBAL_HEADER_DEFINITION

#include <Bela.h>
#include <stdio.h>

#define SCOPE_ON true
#define PRINT_ON true

#define OSC_INPORT 7562
#define OSC_OUTPORT 7563
#define OSC_LOCALHOST "127.0.0.1"
#define OSC_TIMEOUT 3

#define DEFAULT_BPM 120
#define MIDI_DIVIDER 0.007874f
#define WEB_DIVIDER 0.0009765625f

typedef unsigned int uint;
typedef unsigned char uchar;

extern const float *SAMPLERATE;
extern const float *ONE_OVER_SAMPLERATE;
extern const float *INERTIA;

#endif