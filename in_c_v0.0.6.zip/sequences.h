#ifndef _SEQUENCES_HEADER_DEFINITION
#define _SEQUENCES_HEADER_DEFINITION
#include "global.h"

namespace SEQUENCES {
/*~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/* SEQUENCE DATA STRUCTURES */
/*~~~~~~~~~~~~~~~~~~~~~~~~~~*/
// Event is an instance of note on or off
// Constructor defines what it is
typedef struct Event {
	Event(bool t, uchar n, uchar v) {
		type = t;
		note = n;
		vel = v;
	}
	bool type;
	uchar note;
	uchar vel;
} Event;

// A Tick is a pointer of an event
// Lack of an actual event implies nothing happens on said tick.
typedef Event *Tick;

// Sequence class //
// Is a container for an array of type
// Tick which are pointers to events initialized to null.
class Sequence {
	uint _length;
	Tick *_seq;
	
	public:
	Sequence(uint length) {
		_length = length;
		_seq = new Tick[length] { nullptr }; // Initialize to nullptr to avoid garbage.
	};
	~Sequence(void) { delete[] _seq; }
	
	void setTick(uint index, bool on, uchar note, uchar vel) { _seq[index] = new Event(on, note, vel); }
	Event * getTick(uint index) { return _seq[index]; }
	uint length(void) { return _length; }
};

/*~~~~~~~~~~~~~~~~~~*/
/* SEQUENCE MANAGER */
/*~~~~~~~~~~~~~~~~~~*/
// A container for an array of class	
// type Sequence. Construction loads	
// and parses MIDI files into a	Sequence object						
class SequenceManager {
	uint _totalSequences;
	uint _ticksPerBeat;
	
	Sequence **_sequences; // TOBE: Defined as array of type sequence
	
	public:
	SequenceManager(void);
	~SequenceManager(void);

	Sequence *getSequence(int i) const { return _sequences[i]; }
	uint getTicksPerBeat() const { return _ticksPerBeat; }
	uint getTotalSequences() const { return _totalSequences; }
};

/*~~~~~~~*/
/* CLOCK */
/*~~~~~~~*/

class Clock {
	const SequenceManager &_seqManager;
	const uint _ticksPerBeat;
	uint _samplesPerTick;
	bool _play;
	uint _sampleCount = 0;
	uint _tickCount = 0;
	
	public:
	Clock(const SequenceManager &seq):
	_seqManager(seq), _ticksPerBeat(_seqManager.getTicksPerBeat() * 4.0f), _play(false) { setTempo(DEFAULT_BPM); }
	void process(void);
	
	void setTempo(float bpm);
	bool isNewBeat(void) const { return _tickCount == 0 && _sampleCount == 0; }
	bool isNewTick(void) const { return _sampleCount == 0; }
	bool play() const { return _play; }
	bool play(bool status) { return _play = status; }
	uint getTickCount() const { return _tickCount; }
};

class Sequencer {
	Sequence *_seq;
	uint _currentTickIndex;

	public:
	Sequencer(Sequence *seq): _seq(seq), _currentTickIndex(0) {}
	Tick getTick();
	void nextTick();
	
	void setSequence(const Sequence *seq);
	void setIndex(uint index);
	uint getIndex();
};
}
#endif