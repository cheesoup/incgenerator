#ifndef _AUDIO_HEADER_DEFINITION
#define _AUDIO_HEADER_DEFINITION

typedef enum CHANNEL_ENUM {
	CHANNEL_LEFT = 0,
	CHANNEL_RIGHT = 1,
	CHANNEL_ERROR = 2
} CHANNEL_ENUM;

class Audio {
	float _channel[CHANNEL_ERROR];
	public:
	Audio() { reset(); };
	void reset(const float left = 0.0f, const float right = 0.0f) {
		_channel[CHANNEL_LEFT] = left; _channel[CHANNEL_RIGHT] = right;
	}
	
	const Audio & operator+=(const Audio & input) {
		add(input);
		return *this;
	}
	
	void add(const Audio & input) {
		_channel[CHANNEL_LEFT] += input._channel[CHANNEL_LEFT];
		_channel[CHANNEL_RIGHT] += input._channel[CHANNEL_RIGHT];
	}
	
	const Audio & operator+=(float x) {
		add(x);
		return *this;
	}
	
	void add(float x) {
		_channel[CHANNEL_LEFT] += x;
		_channel[CHANNEL_RIGHT] += x;
	}
	
	const Audio & operator*=(const Audio & input) {
		multiply(input);
		return *this;
	}
	
	const Audio & operator*=(float x) {
		multiply(x);
		return *this;
	}
	
	void multiply(const Audio & input) {
		_channel[CHANNEL_LEFT] *= input._channel[CHANNEL_LEFT];
		_channel[CHANNEL_RIGHT] *= input._channel[CHANNEL_RIGHT];
	}
	
	void multiply(float x) {
		_channel[CHANNEL_LEFT] *= x;
		_channel[CHANNEL_RIGHT] *= x;
	}
	
	const Audio & operator=(const Audio & input) {
		set(input);
		return *this;
	}
	
	void set(const Audio & input) {
		_channel[CHANNEL_LEFT] = input._channel[CHANNEL_LEFT];
		_channel[CHANNEL_RIGHT] = input._channel[CHANNEL_RIGHT];
	}
	
	float get(const uchar chan) const { return _channel[chan]; }
	float mono() const { return (_channel[CHANNEL_LEFT] + _channel[CHANNEL_RIGHT]) * 0.5f; }
	float & operator [] (const uchar chan) { return _channel[chan]; }
};

#endif