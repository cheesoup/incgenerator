var socket;
var registered = false;

//~~~~~~~~~~~~~~~~~//
// Websocket stuff //
//~~~~~~~~~~~~~~~~~//

window.onload = function() {
	socket_connect('http://bela.local:8080');
};

function socket_connect(url) {
	socket = io.connect(url);
	socket.on('error', function(data) {
		console.log("Error: " + data);
	});
	socket.on('confirm', function(data) {
		generatePlayerList(data);
	});
	socket.on('playerlist', function(data) {
		updatePlayerList(data);
		drawconsole.newMsg("A new player has joined: " + data.id);
	});
	socket.on('note', function(data) { 
		let selected = playerList.find(o => o.id === data.id);
		if (selected) {
			selected.newNote(data);
			drawconsole.newMsg("Player " + data.id + " received a new note: " + data.note);
		}
	});
	socket.on('pulse', function(data) {
		if (!document.hidden) metronome.newbeat();
	});
	socket.on('control', function(data) {
		let selected = playerList.find(o => o.id === data.id);
		if (selected) selected.setSettings(data);
	});
	socket.on('newseq', function(data) {
		let selected = playerList.find(o => o.id === data.id);
		if(selected) {
			if(selected.newSequence(data)) drawconsole.newMsg("Player "+ data.id + " has started sequence: " + data.sequence + ".");
		}
	});
}

function generatePlayerList(data) {
	console.log("Generating " + data.length + "players.");
	for (let i = 0; i < data.length; i++) {
		var newPlayer = new Player(i, data[i].id, data[i].settings);
		playerList.push(newPlayer);
	}
}

function updatePlayerList(data) {
	if (data.status) {
		for (let i = 0; i < playerList.length; i++) { 
			if (playerList[i].id === data.id) return;
		}
		var newPlayer = new Player(playerList.length, data.id, presets);
		playerList.push(newPlayer);
		console.log("A new player was generated: " + data.id);
	} else {
		for (let i = 0; i < playerList.length; i++) {
			if (playerList[i].id === data.id) {
				playerList.splice(playerList[i], 1);
				console.log("Deleting player: " + data.id);
				break;
			}
		}
	}
}

function controlChange(ctl, val = 0, attr = "") {
	let data = {
		command: ctl,
		attribute: attr,
		value: val
	};
	socket.emit('control', data);
}