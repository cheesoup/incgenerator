#include "dsp.h"
#include "oscillator.h"

using namespace VOICE::OSCILLATOR;

float Oscillator::process(float delta) {
	float out = DSP::SIN(_phase);
	_phase += delta;
	_phase *= !(int)_phase;
	return out;
}

float BasicWaves::process(float delta, float mod, float pw) {
	float waves[3];
	float duty = pw * 0.75f + 0.125f;
	float p = pwPhase(duty);
	
	// Sawtooth is required to generate a square wave
	// Synthesize by taking _phase and stretching to -1 and 1
	waves[SAW] = DSP::WRAP(p + 0.5f) * 2.0f - 1.0f;
	waves[SAW] -= polyBLEP(0.5f + (0.5f - duty), delta);
	
	// Square wave is required to generate all other shapes
	// Synthesize by integrating a second niave saw into the first saw
	waves[PULSE] = waves[SAW] - (p * 2.0f - 1.0f);
	waves[PULSE] += polyBLEP(0.0f, delta);
	
	// Exponential _phase value
	// amplitude modulated by the square wave
	waves[EXPO] = DSP::WRAP(p * 2.0f);
	waves[EXPO] *= waves[EXPO] * waves[PULSE];
	
	// Increment Phase
	_phase += delta;
	_phase = DSP::WRAP(_phase);
		
	// Linear interpolation between adjacent waves, y = (1-x)a + xb	
	float shape = mod * 2.0;
	float interpolate = DSP::WRAP(shape);
	return waves[(int)shape] * (1.0f - interpolate) + waves[(int)shape + 1] * interpolate;
}
